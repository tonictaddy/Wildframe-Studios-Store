WILDFRAME STUDIOS CONCEPT STORE

OPEN: index.html in a modern browser on a computer. The file is self-contained, with no server or build tools needed. An internet connection is optional, only for custom Google Fonts; fallback fonts work offline.

CURRENT FEATURES:
- Responsive home page and category navigation
- 37 initial merchandise concept listings
- Search, sort, category and character filters
- Product detail dialog, selectable variants and quantity
- Persistent demo cart in the current browser (localStorage)
- Entirely fake checkout, no orders or payment collection

BEFORE PUBLIC SHARING:
- All graphics are abstract placeholders, not official character art.
- Confirm official names, product concepts, lore, descriptions, and pricing.
- Do not assume this is access-controlled: an HTML file shared with others can be copied; publicly hosting it makes it public.
- Do not connect payments until production, legal and inventory readiness.

HOSTING LATER: GitHub Pages, Cloudflare Pages or similar static hosting.
